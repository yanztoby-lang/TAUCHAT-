# TAUCHAT 100 Mini-Games Expansion

Berisi katalog 100 game tambahan:
- 25 Slot Hiburan (simulasi gratis tanpa taruhan)
- 25 Tembak & Arcade
- 50 Asah Otak

Tiga template interaktif yang digunakan:
- Slot simulasi: reel acak dan poin hiburan lokal.
- Tembak arcade: target tap dan skor.
- Asah otak: kuis logika pilihan ganda.

## Cara menghasilkan APK melalui GitHub Actions
1. Buat repository GitHub baru.
2. Ekstrak ZIP ini lalu unggah seluruh isi folder ke repository, termasuk folder `.github`.
3. Buka tab **Actions** di repository.
4. Pilih workflow **Build TAUCHAT Android APK** lalu tekan **Run workflow** (atau push ke branch `main`).
5. Setelah proses selesai, buka hasil workflow dan unduh artifact `tauchat-100-games-debug-apk`.
6. Ekstrak artifact untuk mendapatkan `app-debug.apk`.

## Cara build lokal
Buka folder proyek ini di Android Studio, tunggu Gradle Sync, lalu pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Catatan penting
- Saya belum dapat mengeluarkan APK hasil kompilasi langsung dari sesi ini karena Android SDK dan Gradle tidak tersedia di lingkungan build.
- Workflow GitHub Actions disertakan agar proyek dapat dikompilasi menjadi APK debug.
- APK debug bukan APK rilis Play Store; untuk distribusi publik perlu signing release, pengujian perangkat, kebijakan privasi, dan pemeriksaan kebijakan Google Play.
- Tidak semua 100 judul merupakan mekanik unik; setiap judul membuka template sesuai kategori.
- Poin slot/hiburan bersifat lokal, tidak dapat dibeli, diuangkan, ditarik, atau dipertukarkan.
- Belum ada backend, multiplayer, sinkronisasi akun, aset animasi khusus, pembayaran, atau panel admin.
