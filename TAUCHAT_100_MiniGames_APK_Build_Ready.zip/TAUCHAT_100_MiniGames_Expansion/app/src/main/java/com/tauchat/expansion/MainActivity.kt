package com.tauchat.expansion

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

private val Bg = Color(0xFF090711)
private val Panel = Color(0xFF1D1630)
private val Purple = Color(0xFFBE70FF)
private val White = Color(0xFFF7F0FF)

data class MiniGame(val id: Int, val name: String, val category: String)

private val allGames = listOf(
    MiniGame(1, "Slot Aurora", "Slot Hiburan"),
    MiniGame(2, "Slot Naga Emas", "Slot Hiburan"),
    MiniGame(3, "Slot Harta Karun", "Slot Hiburan"),
    MiniGame(4, "Slot Permata Neon", "Slot Hiburan"),
    MiniGame(5, "Slot Buah Tropis", "Slot Hiburan"),
    MiniGame(6, "Slot Galaxy", "Slot Hiburan"),
    MiniGame(7, "Slot Phoenix", "Slot Hiburan"),
    MiniGame(8, "Slot Petir Ungu", "Slot Hiburan"),
    MiniGame(9, "Slot Samurai", "Slot Hiburan"),
    MiniGame(10, "Slot Laut Dalam", "Slot Hiburan"),
    MiniGame(11, "Slot Candy Pop", "Slot Hiburan"),
    MiniGame(12, "Slot Robot", "Slot Hiburan"),
    MiniGame(13, "Slot Jungle", "Slot Hiburan"),
    MiniGame(14, "Slot Es Kristal", "Slot Hiburan"),
    MiniGame(15, "Slot Bintang", "Slot Hiburan"),
    MiniGame(16, "Slot Koi Fortune", "Slot Hiburan"),
    MiniGame(17, "Slot Raja Hutan", "Slot Hiburan"),
    MiniGame(18, "Slot Hujan Meteor", "Slot Hiburan"),
    MiniGame(19, "Slot Cyber City", "Slot Hiburan"),
    MiniGame(20, "Slot Kupu-Kupu", "Slot Hiburan"),
    MiniGame(21, "Tembak Ikan Raja", "Tembak & Arcade"),
    MiniGame(22, "Tembak Ikan Naga", "Tembak & Arcade"),
    MiniGame(23, "Tembak Ikan Hiu", "Tembak & Arcade"),
    MiniGame(24, "Tembak Ikan Paus", "Tembak & Arcade"),
    MiniGame(25, "Tembak Ikan Gurita", "Tembak & Arcade"),
    MiniGame(26, "Tembak Monster Laut", "Tembak & Arcade"),
    MiniGame(27, "Tembak Alien", "Tembak & Arcade"),
    MiniGame(28, "Tembak Meteor", "Tembak & Arcade"),
    MiniGame(29, "Tembak Drone", "Tembak & Arcade"),
    MiniGame(30, "Tembak Target Neon", "Tembak & Arcade"),
    MiniGame(31, "Penjaga Galaksi", "Tembak & Arcade"),
    MiniGame(32, "Pertahanan Kastil", "Tembak & Arcade"),
    MiniGame(33, "Serbu Robot", "Tembak & Arcade"),
    MiniGame(34, "Lawan Naga", "Tembak & Arcade"),
    MiniGame(35, "Pemanah Hutan", "Tembak & Arcade"),
    MiniGame(36, "Bubble Shooter", "Tembak & Arcade"),
    MiniGame(37, "Target Bergerak", "Tembak & Arcade"),
    MiniGame(38, "Balon Meletus", "Tembak & Arcade"),
    MiniGame(39, "Laser Defender", "Tembak & Arcade"),
    MiniGame(40, "Raja Arena", "Tembak & Arcade"),
    MiniGame(41, "Tebak Angka Rahasia", "Asah Otak"),
    MiniGame(42, "Tebak Kata", "Asah Otak"),
    MiniGame(43, "Tebak Gambar", "Asah Otak"),
    MiniGame(44, "Tebak Emoji", "Asah Otak"),
    MiniGame(45, "Susun Kata", "Asah Otak"),
    MiniGame(46, "Memori Kartu", "Asah Otak"),
    MiniGame(47, "Mahjong Match", "Asah Otak"),
    MiniGame(48, "Puzzle Geser", "Asah Otak"),
    MiniGame(49, "Sudoku Mini", "Asah Otak"),
    MiniGame(50, "Nonogram", "Asah Otak"),
    MiniGame(51, "Teka-Teki Logika", "Asah Otak"),
    MiniGame(52, "Hitung Cepat", "Asah Otak"),
    MiniGame(53, "Matematika Kilat", "Asah Otak"),
    MiniGame(54, "Cari Perbedaan", "Asah Otak"),
    MiniGame(55, "Cari Objek", "Asah Otak"),
    MiniGame(56, "Labirin Misteri", "Asah Otak"),
    MiniGame(57, "Urutkan Warna", "Asah Otak"),
    MiniGame(58, "Cocokkan Bentuk", "Asah Otak"),
    MiniGame(59, "Pola Berikutnya", "Asah Otak"),
    MiniGame(60, "Ingat Urutan", "Asah Otak"),
    MiniGame(61, "Tic Tac Toe", "Asah Otak"),
    MiniGame(62, "Batu Gunting Kertas", "Asah Otak"),
    MiniGame(63, "Catur Mini", "Asah Otak"),
    MiniGame(64, "Dam Mini", "Asah Otak"),
    MiniGame(65, "Domino Puzzle", "Asah Otak"),
    MiniGame(66, "2048 Neon", "Asah Otak"),
    MiniGame(67, "Blok Puzzle", "Asah Otak"),
    MiniGame(68, "Jigsaw Santai", "Asah Otak"),
    MiniGame(69, "Tangram", "Asah Otak"),
    MiniGame(70, "Menara Hanoi", "Asah Otak"),
    MiniGame(71, "Kuis Pengetahuan", "Asah Otak"),
    MiniGame(72, "Kuis Sains", "Asah Otak"),
    MiniGame(73, "Kuis Sejarah", "Asah Otak"),
    MiniGame(74, "Kuis Musik", "Asah Otak"),
    MiniGame(75, "Kuis Dunia", "Asah Otak"),
    MiniGame(76, "Reaksi Cepat", "Asah Otak"),
    MiniGame(77, "Ketuk Berirama", "Asah Otak"),
    MiniGame(78, "Warna atau Kata", "Asah Otak"),
    MiniGame(79, "Tebak Bayangan", "Asah Otak"),
    MiniGame(80, "Tebak Suara", "Asah Otak"),
    MiniGame(81, "Jalur Pipa", "Asah Otak"),
    MiniGame(82, "Sambung Titik", "Asah Otak"),
    MiniGame(83, "Jembatan Angka", "Asah Otak"),
    MiniGame(84, "Kunci Kode", "Asah Otak"),
    MiniGame(85, "Detektif Petunjuk", "Asah Otak"),
    MiniGame(86, "Balap Hitung", "Asah Otak"),
    MiniGame(87, "Pasangan Simbol", "Asah Otak"),
    MiniGame(88, "Susun Huruf", "Asah Otak"),
    MiniGame(89, "Peta Harta Karun", "Asah Otak"),
    MiniGame(90, "Tantangan Fokus", "Asah Otak"),
    MiniGame(91, "Roda Keberuntungan", "Slot Hiburan"),
    MiniGame(92, "Kotak Kejutan", "Slot Hiburan"),
    MiniGame(93, "Kartu Keberuntungan", "Slot Hiburan"),
    MiniGame(94, "Pilih Peti Harta", "Slot Hiburan"),
    MiniGame(95, "Putar Kristal", "Slot Hiburan"),
    MiniGame(96, "Kapal Selam Arcade", "Tembak & Arcade"),
    MiniGame(97, "Benteng Laser", "Tembak & Arcade"),
    MiniGame(98, "Serangan Meteor", "Tembak & Arcade"),
    MiniGame(99, "Penembak Gelembung", "Tembak & Arcade"),
    MiniGame(100, "Boss Raja Laut", "Tembak & Arcade")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ExpansionApp() }
    }
}

@Composable
fun ExpansionApp() {
    var filter by remember { mutableStateOf("Semua") }
    var chosen by remember { mutableStateOf<MiniGame?>(null) }
    val categories = listOf("Semua", "Slot Hiburan", "Tembak & Arcade", "Asah Otak")
    val filtered = allGames.filter { filter == "Semua" || it.category == filter }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(14.dp)) {
            Text("TAUCHAT ARCADE+", color = Purple, fontSize = 27.sp, fontWeight = FontWeight.Black)
            Text("100 GAME BARU • MAIN UNTUK HIBURAN", color = White.copy(.7f), fontSize = 11.sp)
            Spacer(Modifier.height(14.dp))
            if (chosen == null) {
                Text("Pilih kategori", color = White, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 10.dp)) {
                    categories.forEach { c ->
                        FilterChip(selected = filter == c, onClick = { filter = c }, label = { Text(c, fontSize = 10.sp) })
                    }
                }
                Text("${filtered.size} permainan", color = Purple, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                LazyVerticalGrid(columns = GridCells.Fixed(2), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(filtered) { game ->
                        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).clickable { chosen = game }.padding(12.dp)) {
                            Text(when(game.category) { "Slot Hiburan" -> "🎰"; "Tembak & Arcade" -> "🎯"; else -> "🧠" }, fontSize = 27.sp)
                            Text(game.name, color = White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(game.category, color = Purple, fontSize = 10.sp)
                            Text("BUKA GAME →", color = White.copy(.65f), fontSize = 9.sp)
                        }
                    }
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("← Kembali", color = Purple, modifier = Modifier.clickable { chosen = null })
                    Spacer(Modifier.width(14.dp))
                    Text(chosen!!.name, color = White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(20.dp))
                when(chosen!!.category) {
                    "Slot Hiburan" -> SlotPlay(chosen!!.name)
                    "Tembak & Arcade" -> ShootingPlay(chosen!!.name)
                    else -> BrainPlay(chosen!!.name)
                }
            }
        }
    }
}

@Composable
fun GameFrame(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(14.dp))
        content()
    }
}
@Composable
fun GameButton(label: String, onClick: () -> Unit) {
    Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text(label, color = Color.Black, fontWeight = FontWeight.Bold) }
}

@Composable
fun SlotPlay(name: String) {
    val symbols = listOf("🍒","🍋","🔔","💎","⭐","🐉","7️⃣")
    var reels by remember { mutableStateOf(listOf("❔","❔","❔")) }
    var spins by remember { mutableIntStateOf(0) }
    var points by remember { mutableIntStateOf(0) }
    var status by remember { mutableStateOf("Tekan PUTAR untuk mengacak simbol.") }
    GameFrame("🎰 $name") {
        Text(reels.joinToString("     "), color = White, fontSize = 34.sp)
        Text(status, color = Purple, fontWeight = FontWeight.Bold)
        Text("Putaran: $spins  •  Poin hiburan: $points", color = White.copy(.75f))
        GameButton("PUTAR REEL", onClick = {
            val next = List(3) { symbols.random() }
            reels = next; spins++
            if (next.distinct().size == 1) { points += 30; status = "Jackpot simbol! +30 poin hiburan" }
            else if (next.distinct().size == 2) { points += 5; status = "Dua simbol cocok! +5 poin hiburan" }
            else status = "Coba lagi! Tidak ada poin pada putaran ini."
        })
        GameButton("Reset", onClick = { reels = listOf("❔","❔","❔"); spins = 0; points = 0; status = "Tekan PUTAR untuk mengacak simbol." })
        Text("Simulasi slot gratis. Tidak ada taruhan, pembelian putaran, penukaran, atau hadiah uang.", color = White.copy(.55f), fontSize = 10.sp)
    }
}

@Composable
fun ShootingPlay(name: String) {
    var score by remember { mutableIntStateOf(0) }
    var target by remember { mutableIntStateOf(Random.nextInt(1, 10)) }
    var shots by remember { mutableIntStateOf(0) }
    GameFrame("🎯 $name") {
        Text("Target muncul di arena. Ketuk target untuk menembak!", color = White)
        Text("🎯", fontSize = 48.sp)
        Text("Target #$target", color = Purple, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("Skor: $score  •  Tembakan: $shots", color = White)
        GameButton("🔫 TEMBAK TARGET", onClick = {
            shots++
            if (Random.nextInt(100) < 72) { score += 10; target = Random.nextInt(1, 10) }
        })
        GameButton("Reset ronde", onClick = { score = 0; shots = 0; target = Random.nextInt(1,10) })
        Text("Prototipe arcade tap-target; bukan simulasi senjata nyata.", color = White.copy(.55f), fontSize = 10.sp)
    }
}

@Composable
fun BrainPlay(name: String) {
    val questions = listOf(
        Triple("2 + 5 × 2 = ?", listOf("14","12","9"), "12"),
        Triple("Lanjutkan pola: 2, 4, 8, 16, ...", listOf("18","24","32"), "32"),
        Triple("Kata yang berbeda: Apel, Mangga, Wortel", listOf("Apel","Mangga","Wortel"), "Wortel"),
        Triple("Ada 3 apel, diambil 1. Berapa apel yang kamu punya?", listOf("1","2","3"), "1"),
        Triple("Huruf setelah M adalah ...", listOf("L","N","O"), "N")
    )
    var index by remember { mutableIntStateOf(Random.nextInt(questions.size)) }
    var points by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf("Pilih jawaban yang benar.") }
    val q = questions[index]
    GameFrame("🧠 $name") {
        Text(q.first, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        q.second.forEach { answer ->
            GameButton(answer, onClick = {
                if (answer == q.third) { points += 10; feedback = "Benar! +10 poin." }
                else feedback = "Belum tepat. Coba soal berikutnya."
            })
        }
        Text(feedback, color = Purple)
        Text("Skor latihan: $points", color = White)
        GameButton("Soal berikutnya", onClick = { index = (index + 1) % questions.size; feedback = "Pilih jawaban yang benar." })
        GameButton("Reset skor", onClick = { points = 0; feedback = "Skor direset." })
    }
}
